"""
Reports & Data Exports
Filter-Aware CSV Downloads, Privacy-Preserving De-Identification & Executive PDF Generation
"""

import os
import streamlit as st
import pandas as pd
from reporting.csv_exporter import export_filtered_dataset
from reporting.pdf_generator import generate_executive_pdf_report
from ml_engine.evaluator import get_latest_model_metrics
from core.database import query_db

def render(df: pd.DataFrame, active_filters: dict):
    st.markdown("## 📑 Clinical Intelligence Reports & Filter-Aware Exports")
    st.caption("Generate encrypted executive PDF reports or download filter-aware cohort datasets with automatic privacy masking.")

    user = st.session_state.get("user", {})
    username = user.get("username", "anonymous")
    role = user.get("role", "Read-only Viewer")

    col_pdf, col_csv = st.columns(2)

    # 1. Executive PDF Report Generation
    with col_pdf:
        st.markdown(
            """
            <div class="cyber-card" style="border-top: 4px solid #00f2fe; height: 100%;">
                <h4 style="color: #00f2fe; margin-top: 0;">📄 Executive Clinical PDF Report</h4>
                <p style="font-size: 0.86rem; color: #cbd5e1;">
                    Generates a formal executive surveillance document including cohort prevalence,
                    biomarker distributions, machine learning evaluation tables, and governance disclaimers.
                </p>
            </div>
            """,
            unsafe_allow_html=True
        )
        if st.button("🚀 Compile & Download Executive PDF Report", use_container_width=True):
            with st.spinner("Generating formal ReportLab clinical PDF document..."):
                try:
                    q_rows = query_db("SELECT quality_score FROM data_quality_metrics ORDER BY id DESC LIMIT 1")
                    q_score = q_rows[0]["quality_score"] if q_rows else 95.0
                    models_meta = get_latest_model_metrics()
                    
                    pdf_path = generate_executive_pdf_report(
                        df=df,
                        quality_metrics={"quality_score": q_score},
                        models_summary=models_meta,
                        generated_by=f"{user.get('full_name')} ({role})"
                    )

                    with open(pdf_path, "rb") as f:
                        pdf_bytes = f.read()

                    st.download_button(
                        label="📥 Click to Save PDF Document",
                        data=pdf_bytes,
                        file_name=os.path.basename(pdf_path),
                        mime="application/pdf",
                        use_container_width=True
                    )
                    st.success("Executive PDF report generated successfully.")
                except Exception as e:
                    st.error(f"PDF compilation failed: {str(e)}")

    # 2. Filter-Aware CSV Export
    with col_csv:
        st.markdown(
            f"""
            <div class="cyber-card" style="border-top: 4px solid #4facfe; height: 100%;">
                <h4 style="color: #4facfe; margin-top: 0;">📊 Filter-Aware CSV Cohort Export</h4>
                <p style="font-size: 0.86rem; color: #cbd5e1;">
                    Exports records matching active filters (<b>{len(df):,} patients</b>). 
                    Researchers automatically receive pseudonymized tokens with date perturbation.
                </p>
            </div>
            """,
            unsafe_allow_html=True
        )
        
        csv_data = export_filtered_dataset(
            df=df,
            filters_applied=active_filters,
            username=username,
            role=role
        )

        if csv_data:
            st.download_button(
                label=f"📥 Download Filtered CSV ({len(df):,} records)",
                data=csv_data,
                file_name=f"chronic_disease_cohort_{len(df)}_pts.csv",
                mime="text/csv",
                use_container_width=True
            )
        else:
            st.error(f"User role '{role}' is restricted from exporting cohort data.")

    # 3. Clinical Data Dictionary
    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)
    st.markdown("#### 📖 Clinical Data Dictionary & Variable Definitions")
    from data_pipeline.exporter import DATA_DICTIONARY_ROWS
    dict_df = pd.DataFrame(DATA_DICTIONARY_ROWS)
    st.dataframe(dict_df, use_container_width=True, hide_index=True)
