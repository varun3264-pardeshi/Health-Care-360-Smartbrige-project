"""
Dashboard B: Clinical Risk Assessment
Physiological Biomarker Surveillance, Hemodynamics, Glycemic & Lipid Profiling
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from ui.theme import apply_plotly_cyber_theme

def render(df: pd.DataFrame, active_filters: dict):
    st.markdown("## 🩺 Dashboard B: Clinical Risk Assessment")
    st.caption("Deep-dive hemodynamic, lipid, and glycemic biomarker stratification.")

    if len(df) == 0:
        st.warning("No records match active filters.")
        return

    # 1. Clinical Biomarker Distributions Row 1
    c1, c2 = st.columns(2)

    with c1:
        st.markdown("#### 🩸 Blood Pressure Hemodynamics (Systolic vs Diastolic)")
        # Sample max 1500 points for crisp interactive performance
        sample_df = df.sample(min(len(df), 1500), random_state=42)

        fig_bp = px.scatter(
            sample_df,
            x="systolic_bp",
            y="diastolic_bp",
            color="bp_category",
            color_discrete_map={
                "Normal": "#00f5a0",
                "Elevated": "#4facfe",
                "Hypertension Stage 1": "#ffaa00",
                "Hypertension Stage 2": "#ff6b6b",
                "Hypertensive Crisis": "#ff0055"
            },
            hover_data=["patient_id", "age", "heart_disease", "stroke"],
            labels={"systolic_bp": "Systolic BP (mmHg)", "diastolic_bp": "Diastolic BP (mmHg)"}
        )
        # Add AHA Reference threshold lines
        fig_bp.add_vline(x=130, line_dash="dash", line_color="rgba(255, 170, 0, 0.5)", annotation_text="Stage 1 SBP")
        fig_bp.add_vline(x=140, line_dash="dash", line_color="rgba(255, 51, 102, 0.5)", annotation_text="Stage 2 SBP")
        fig_bp.add_hline(y=90, line_dash="dash", line_color="rgba(255, 51, 102, 0.5)", annotation_text="Stage 2 DBP")
        apply_plotly_cyber_theme(fig_bp)
        st.plotly_chart(fig_bp, use_container_width=True)

    with c2:
        st.markdown("#### 🧪 Glycemic Dysregulation (Fasting Glucose vs HbA1c)")
        fig_gluc = px.scatter(
            sample_df,
            x="fasting_glucose",
            y="hba1c",
            color="glucose_category",
            color_discrete_map={
                "Normal": "#00f5a0",
                "Prediabetes": "#ffaa00",
                "Diabetes": "#ff3366"
            },
            hover_data=["patient_id", "bmi", "diabetes"],
            labels={"fasting_glucose": "Fasting Glucose (mg/dL)", "hba1c": "HbA1c Glycated Hemoglobin (%)"}
        )
        fig_gluc.add_vline(x=126, line_dash="dash", line_color="#ff3366", annotation_text="ADA Diabetic (126)")
        fig_gluc.add_hline(y=6.5, line_dash="dash", line_color="#ff3366", annotation_text="ADA Diabetic (6.5%)")
        apply_plotly_cyber_theme(fig_gluc)
        st.plotly_chart(fig_gluc, use_container_width=True)

    # 2. Row 2: Cholesterol Profiles & BMI Distribution
    c3, c4 = st.columns(2)

    with c3:
        st.markdown("#### 🧬 Serum Lipid Profiles (LDL vs HDL by Condition)")
        fig_chol = px.scatter(
            sample_df,
            x="cholesterol_ldl",
            y="cholesterol_hdl",
            color="heart_disease",
            color_continuous_scale=["#4facfe", "#ff3366"],
            labels={"cholesterol_ldl": "LDL (Bad) Cholesterol mg/dL", "cholesterol_hdl": "HDL (Protective) Cholesterol mg/dL"},
            hover_data=["patient_id", "cholesterol_ratio"]
        )
        fig_chol.update_layout(coloraxis_colorbar=dict(title="Heart Disease (1/0)"))
        apply_plotly_cyber_theme(fig_chol)
        st.plotly_chart(fig_chol, use_container_width=True)

    with c4:
        st.markdown("#### ⚖️ Body Mass Index (BMI) Violin Distributions")
        fig_bmi_v = px.violin(
            df,
            x="gender",
            y="bmi",
            color="diabetes",
            box=True,
            points=False,
            color_discrete_map={0: "#00f2fe", 1: "#ffaa00"},
            labels={"diabetes": "Diabetes Status (0=Neg, 1=Pos)"}
        )
        apply_plotly_cyber_theme(fig_bmi_v)
        st.plotly_chart(fig_bmi_v, use_container_width=True)

    # 3. Interactive 3D Chronic Risk Galaxy Space
    st.markdown("#### 🌌 3D Chronic Risk Space (Systolic BP × Fasting Glucose × Patient Age)")
    st.caption("Interactive rotatable 3D manifold. Coordinates map Systolic BP (X), Fasting Glucose (Y), and Age (Z). Sphere volume scales with BMI; color denotes Multimorbidity count.")
    sample_3d = df.sample(min(len(df), 800), random_state=42)
    fig_3d = px.scatter_3d(
        sample_3d,
        x="systolic_bp",
        y="fasting_glucose",
        z="age",
        color="multimorbidity_count",
        size="bmi",
        color_continuous_scale="Plasma",
        hover_data=["patient_id", "bp_category", "glucose_category", "heart_disease", "stroke"],
        labels={"systolic_bp": "Systolic BP (mmHg)", "fasting_glucose": "Glucose (mg/dL)", "age": "Age (Yrs)", "multimorbidity_count": "Conditions"}
    )
    fig_3d.update_layout(
        scene=dict(
            xaxis=dict(backgroundcolor="rgba(8, 16, 36, 0.9)", gridcolor="rgba(0, 242, 254, 0.15)", title="Systolic BP (mmHg)"),
            yaxis=dict(backgroundcolor="rgba(8, 16, 36, 0.9)", gridcolor="rgba(0, 242, 254, 0.15)", title="Glucose (mg/dL)"),
            zaxis=dict(backgroundcolor="rgba(8, 16, 36, 0.9)", gridcolor="rgba(0, 242, 254, 0.15)", title="Age (Years)"),
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=0, r=0, t=10, b=0),
        height=520
    )
    st.plotly_chart(fig_3d, use_container_width=True)

    # 4. Clinical Indicator Correlation Heatmap
    st.markdown("#### 🔬 Clinical Biomarker Correlation Matrix")
    corr_cols = [
        "age", "bmi", "systolic_bp", "diastolic_bp", "cholesterol_total",
        "cholesterol_hdl", "cholesterol_ldl", "fasting_glucose", "hba1c",
        "physical_activity_mins", "heart_disease", "diabetes", "stroke"
    ]
    corr_matrix = df[corr_cols].corr()

    fig_corr = px.imshow(
        corr_matrix,
        text_auto=".2f",
        aspect="auto",
        color_continuous_scale="RdBu_r",
        zmin=-0.6,
        zmax=0.6
    )
    apply_plotly_cyber_theme(fig_corr)
    st.plotly_chart(fig_corr, use_container_width=True)

    # 4. Disease Positive vs Disease Negative Comparison Table
    st.markdown("#### 📊 Comparative Biomarker Averages (Disease Positive vs Negative)")
    summary_data = []
    for cond_name, col in [("Heart Disease", "heart_disease"), ("Type 2 Diabetes", "diabetes"), ("Stroke", "stroke")]:
        pos = df[df[col] == 1]
        neg = df[df[col] == 0]
        summary_data.append({
            "Target Condition": cond_name,
            "Positive Cases": f"{len(pos):,}",
            "Negative Cases": f"{len(neg):,}",
            "Avg Age (Pos vs Neg)": f"{pos['age'].mean():.1f} vs {neg['age'].mean():.1f} yrs",
            "Avg SBP (Pos vs Neg)": f"{pos['systolic_bp'].mean():.1f} vs {neg['systolic_bp'].mean():.1f} mmHg",
            "Avg Glucose (Pos vs Neg)": f"{pos['fasting_glucose'].mean():.1f} vs {neg['fasting_glucose'].mean():.1f} mg/dL",
            "Avg BMI (Pos vs Neg)": f"{pos['bmi'].mean():.1f} vs {neg['bmi'].mean():.1f}"
        })
    st.dataframe(pd.DataFrame(summary_data), use_container_width=True, hide_index=True)
