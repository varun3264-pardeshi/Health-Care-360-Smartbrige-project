"""
PulsePoint Cyber-Medical Intelligence System
Main Streamlit Application Entrypoint
"""

import streamlit as st
import pandas as pd
from streamlit_option_menu import option_menu

from core.config import APP_NAME, APP_VERSION
from data_pipeline.exporter import load_dataset
from ui.theme import CYBER_MEDICAL_CSS
from ui.components.navbar import render_navbar
from ui.components.filters import render_global_filters
from ui.components.anatomical_viewer import render_anatomical_organ_viewer

# Import all page renderers
import ui.pages.dashboard_a_executive as p_exec
import ui.pages.dashboard_b_clinical as p_clin
import ui.pages.dashboard_c_lifestyle as p_life
import ui.pages.dashboard_d_population as p_pop
import ui.pages.ml_risk_predictor as p_ml
import ui.pages.patient_360 as p_pt360
import ui.pages.alert_center as p_alerts
import ui.pages.reports_exports as p_reports
import ui.pages.data_quality as p_qual
import ui.pages.tableau_studio as p_tableau

# Page Configuration
st.set_page_config(
    page_title="PulsePoint Cyber-Medical Intelligence",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inject Cyber-Medical Stylesheet
st.markdown(CYBER_MEDICAL_CSS, unsafe_allow_html=True)


@st.cache_data(ttl=600)
def get_cached_dataset() -> pd.DataFrame:
    """Load and cache processed chronic disease cohort."""
    return load_dataset()


def main():
    # 1. Render Top Navigation Bar & Session Chip
    render_navbar()

    # 2. Load Processed Dataset
    try:
        raw_cohort_df = get_cached_dataset()
    except Exception as e:
        st.error(f"Failed to load dataset: {str(e)}")
        return

    # 3. Sidebar Navigation & Menu
    with st.sidebar:
        st.markdown(
            """
            <div style="padding: 10px 0 16px 0; text-align: center;">
                <div style="font-size: 1.15rem; font-weight: 800; color: #00f2fe; letter-spacing: 0.05em;">
                    ⚡ COMMAND CENTER
                </div>
                <div style="font-size: 0.75rem; color: #8b949e; letter-spacing: 0.05em;">
                    CHRONIC DISEASE INTELLIGENCE
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        selected_page = option_menu(
            menu_title=None,
            options=[
                "Executive Overview",
                "Clinical Risk Assessment",
                "Lifestyle & Symptoms",
                "Population Insights",
                "Anatomical Visualizer",
                "AI/ML Risk Predictor",
                "Patient 360 Deep-Dive",
                "Clinical Alert Center",
                "Reports & Data Exports",
                "Data Quality Auditor",
                "Tableau Integration Studio"
            ],
            icons=[
                "speedometer2",
                "heart-pulse",
                "activity",
                "people",
                "diagram-3",
                "cpu",
                "person-vcard",
                "bell",
                "file-earmark-arrow-down",
                "shield-check",
                "bar-chart-line"
            ],
            menu_icon="cast",
            default_index=0,
            styles={
                "container": {"padding": "0!important", "background-color": "transparent"},
                "icon": {"color": "#00f2fe", "font-size": "14px"},
                "nav-link": {
                    "font-size": "13px",
                    "text-align": "left",
                    "margin": "3px",
                    "color": "#cbd5e1",
                    "border-radius": "6px",
                    "padding": "8px 12px"
                },
                "nav-link-selected": {
                    "background": "linear-gradient(90deg, rgba(0, 242, 254, 0.2) 0%, rgba(79, 172, 254, 0.1) 100%)",
                    "color": "#00f2fe",
                    "border-left": "3px solid #00f2fe",
                    "font-weight": "600"
                }
            }
        )

        st.markdown("<hr style='border-color: rgba(0, 242, 254, 0.15); margin: 20px 0 12px 0;'/>", unsafe_allow_html=True)
        st.markdown(
            f"""
            <div style="font-size: 0.72rem; color: #64748b; line-height: 1.4;">
                <b>PulsePoint Enterprise v{APP_VERSION}</b><br/>
                Engine: Scikit-learn + FastAPI<br/>
                SQLite Database: Connected<br/>
                Synthetic Demo Cohort: Active
            </div>
            """,
            unsafe_allow_html=True
        )

    # 4. Render Global Cross-Filters (Applicable across analytical dashboards)
    filtered_df, active_filters = render_global_filters(raw_cohort_df)

    # 5. Route to Selected Page
    if selected_page == "Executive Overview":
        p_exec.render(filtered_df, active_filters)
    elif selected_page == "Clinical Risk Assessment":
        p_clin.render(filtered_df, active_filters)
    elif selected_page == "Lifestyle & Symptoms":
        p_life.render(filtered_df, active_filters)
    elif selected_page == "Population Insights":
        p_pop.render(filtered_df, active_filters)
    elif selected_page == "Anatomical Visualizer":
        render_anatomical_organ_viewer(filtered_df)
    elif selected_page == "AI/ML Risk Predictor":
        p_ml.render()
    elif selected_page == "Patient 360 Deep-Dive":
        p_pt360.render(filtered_df)
    elif selected_page == "Clinical Alert Center":
        p_alerts.render()
    elif selected_page == "Reports & Data Exports":
        p_reports.render(filtered_df, active_filters)
    elif selected_page == "Data Quality Auditor":
        p_qual.render(filtered_df)
    elif selected_page == "Tableau Integration Studio":
        p_tableau.render()


if __name__ == "__main__":
    main()
