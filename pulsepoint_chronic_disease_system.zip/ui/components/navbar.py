"""
PulsePoint Cyber-Medical Intelligence System
Header Navigation, Animated ECG Waveform & Telemetry Ticker Center
"""

import streamlit as st
from core.security import DEFAULT_USERS, verify_password, create_access_token
from core.database import query_db, execute_db
from core.audit import log_audit_event, EVENT_LOGIN, EVENT_LOGOUT, EVENT_LOGIN_FAILED
from datetime import datetime, timezone

def render_navbar():
    """Renders the cyber-medical navigation bar, animated ECG waveform, and telemetry ticker."""
    
    # Initialize session state if not set
    if "authenticated" not in st.session_state:
        st.session_state.authenticated = True
        st.session_state.user = {
            "username": "dr_chen",
            "full_name": "Dr. Marcus Chen, MD",
            "role": "Authorized Clinician",
            "email": "mchen@pulsepoint.med"
        }

    # Query active alert count for notification badge
    try:
        alert_rows = query_db("SELECT COUNT(*) as c FROM clinical_alerts WHERE status = 'ACTIVE' AND severity = 'CRITICAL'")
        critical_count = alert_rows[0]["c"] if alert_rows else 0
    except Exception:
        critical_count = 0

    col_title, col_ecg, col_notif, col_user, col_logout = st.columns([4.2, 2.5, 2.0, 2.3, 1.0])

    with col_title:
        st.markdown(
            """
            <div style="display: flex; align-items: center; gap: 12px; padding: 4px 0;">
                <div style="width: 14px; height: 14px; border-radius: 50%; background: #00f2fe; box-shadow: 0 0 14px #00f2fe; animation: pulse-critical 1.5s infinite;"></div>
                <div>
                    <span style="font-size: 1.5rem; font-weight: 900; letter-spacing: -0.02em; background: linear-gradient(90deg, #ffffff 0%, #00f2fe 50%, #4facfe 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                        PULSEPOINT
                    </span>
                    <span style="font-size: 0.8rem; color: #4facfe; font-weight: 700; margin-left: 8px; letter-spacing: 0.12em; text-transform: uppercase;">
                        CYBER-MEDICAL v2.4
                    </span>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col_ecg:
        # Animated SVG Real-time ECG Waveform Monitor
        st.markdown(
            """
            <div style="display: flex; align-items: center; gap: 8px; padding-top: 6px;">
                <svg width="120" height="26" viewBox="0 0 120 26" style="overflow: visible;">
                    <path d="M 0 13 L 25 13 L 30 13 L 35 3 L 42 23 L 48 8 L 52 16 L 56 13 L 85 13 L 90 3 L 97 23 L 103 8 L 107 16 L 111 13 L 120 13" 
                          fill="none" 
                          stroke="#00f2fe" 
                          stroke-width="2" 
                          stroke-linecap="round"
                          stroke-linejoin="round">
                        <animate attributeName="stroke-dasharray" from="0,200" to="200,0" dur="2s" repeatCount="indefinite" />
                    </path>
                </svg>
                <span style="font-size: 0.76rem; font-weight: 700; color: #00f5a0; font-family: 'Rajdhani', monospace;">
                    72 BPM ● NORMAL
                </span>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col_notif:
        badge_style = "pill-critical" if critical_count > 0 else "pill-normal"
        st.markdown(
            f"""
            <div style="padding-top: 6px; text-align: right;">
                <span class="status-pill {badge_style}">
                    ⚡ {critical_count} CRITICAL ALERTS
                </span>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col_user:
        current_user = st.session_state.user
        role_color = "#00f2fe" if "Clinician" in current_user["role"] else ("#a855f7" if "Admin" in current_user["role"] else "#ffaa00")
        st.markdown(
            f"""
            <div style="text-align: right; padding-top: 2px;">
                <div style="font-size: 0.88rem; font-weight: 700; color: #f0f6fc;">{current_user['full_name']}</div>
                <div style="font-size: 0.74rem; color: {role_color}; font-weight: 600;">● {current_user['role']}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col_logout:
        with st.popover("Role"):
            st.markdown("<b>Switch Active Profile:</b>", unsafe_allow_html=True)
            for u in DEFAULT_USERS:
                if st.button(f"{u['role']}: {u['username']}", key=f"switch_{u['username']}"):
                    st.session_state.user = {
                        "username": u["username"],
                        "full_name": u["full_name"],
                        "role": u["role"],
                        "email": u["email"]
                    }
                    st.rerun()

    # High-Tech Cyber-Medical Telemetry Ticker Banner
    now_utc = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
    st.markdown(
        f"""
        <div class="telemetry-ticker">
            <div>🟢 NODE: ALPHA-1 (LOCAL)</div>
            <div>📡 POPULATION SURVEILLANCE: ACTIVE</div>
            <div>🧠 AI ENGINES: 3 LOADED</div>
            <div>🛡️ CIPHER: AES-256 / SHA-256</div>
            <div>🕒 CLOCK: {now_utc}</div>
            <div>⚡ SYSTEM HEALTH: 100% OPTIMAL</div>
        </div>
        """,
        unsafe_allow_html=True
    )
