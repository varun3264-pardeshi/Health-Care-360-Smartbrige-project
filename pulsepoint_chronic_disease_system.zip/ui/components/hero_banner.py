"""
Cyber-Medical Hero Banner Component
Renders the executive hero card with holographic AI graphics and live cohort telemetry.
"""

import base64
import os
import streamlit as st

def get_base64_image(image_path: str) -> str:
    """Reads a local image and returns a base64 data URI string."""
    if os.path.exists(image_path):
        with open(image_path, "rb") as f:
            data = f.read()
        ext = os.path.splitext(image_path)[1].replace(".", "")
        if ext == "jpg":
            ext = "jpeg"
        return f"data:image/{ext};base64,{base64.b64encode(data).decode('utf-8')}"
    return ""

def render_executive_hero_banner(cohort_count: int, alert_count: int, model_accuracy: str = "94.2%"):
    """
    Renders an ultra-luxurious cyber-medical executive hero card
    featuring holographic cardiac core visualization and live telemetry feeds.
    """
    img_path = os.path.join(os.path.dirname(__file__), "..", "assets", "cyber_medical_cardiac_core.jpg")
    img_b64 = get_base64_image(img_path)

    img_html = ""
    if img_b64:
        img_html = f"""
        <div style="flex: 0 0 280px; position: relative; overflow: hidden; border-radius: 12px; border: 1px solid rgba(0, 242, 254, 0.4); box-shadow: 0 0 20px rgba(0, 242, 254, 0.25);">
            <img src="{img_b64}" style="width: 100%; height: 180px; object-fit: cover; display: block;" alt="Cyber Cardiac Core"/>
            <div style="position: absolute; bottom: 8px; left: 8px; background: rgba(7, 11, 25, 0.85); border: 1px solid #00f2fe; border-radius: 4px; padding: 2px 8px; font-size: 0.68rem; font-family: 'Rajdhani', monospace; color: #00f2fe; letter-spacing: 0.08em;">
                CORE: CARDIAC AI SCANNER
            </div>
            <div style="position: absolute; top: 8px; right: 8px; width: 8px; height: 8px; background: #00f5a0; border-radius: 50%; box-shadow: 0 0 8px #00f5a0;"></div>
        </div>
        """

    banner_html = f"""
    <div style="
        background: linear-gradient(135deg, rgba(13, 23, 48, 0.92) 0%, rgba(9, 18, 38, 0.95) 100%);
        border: 1px solid rgba(0, 242, 254, 0.35);
        border-radius: 16px;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.1);
        position: relative;
        overflow: hidden;
    ">
        <div style="position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #00f2fe 0%, #a855f7 50%, #00f5a0 100%);"></div>
        <div style="display: flex; flex-direction: row; gap: 24px; align-items: center; justify-content: space-between; flex-wrap: wrap;">
            
            <div style="flex: 1 1 450px;">
                <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(0, 242, 254, 0.12); border: 1px solid rgba(0, 242, 254, 0.3); border-radius: 20px; padding: 4px 12px; margin-bottom: 10px;">
                    <span style="display: inline-block; width: 6px; height: 6px; background-color: #00f5a0; border-radius: 50%; box-shadow: 0 0 6px #00f5a0;"></span>
                    <span style="font-size: 0.72rem; font-family: 'Rajdhani', sans-serif; font-weight: 700; color: #00f2fe; letter-spacing: 0.1em; text-transform: uppercase;">
                        SECURE HEALTH INTELLIGENCE NETWORK // LEVEL-4 SURVEILLANCE
                    </span>
                </div>
                
                <h1 style="margin: 0 0 8px 0; font-size: 1.85rem; font-weight: 800; color: #ffffff; letter-spacing: -0.02em; font-family: 'Outfit', sans-serif;">
                    PulsePoint <span style="background: linear-gradient(90deg, #00f2fe, #4facfe); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Cyber-Medical Command</span>
                </h1>
                
                <p style="margin: 0 0 16px 0; color: #94a3b8; font-size: 0.92rem; line-height: 1.5; max-width: 650px;">
                    Tri-disease prospective risk stratification engine monitoring cardiorenal, glycemic, and cerebrovascular endpoints across Framingham & NHANES benchmark cohorts.
                </p>
                
                <div style="display: flex; gap: 14px; flex-wrap: wrap;">
                    <div style="background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(0, 242, 254, 0.2); border-radius: 8px; padding: 8px 14px;">
                        <div style="font-size: 0.68rem; color: #64748b; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">COHORT VOLUME</div>
                        <div style="font-size: 1.15rem; font-weight: 800; color: #ffffff; font-family: 'Rajdhani', sans-serif;">{cohort_count:,} PATIENTS</div>
                    </div>
                    <div style="background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(255, 51, 102, 0.3); border-radius: 8px; padding: 8px 14px;">
                        <div style="font-size: 0.68rem; color: #ff3366; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">ACTIVE ALERTS</div>
                        <div style="font-size: 1.15rem; font-weight: 800; color: #ff3366; font-family: 'Rajdhani', sans-serif;">{alert_count} TRIGGERED</div>
                    </div>
                    <div style="background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(0, 245, 160, 0.3); border-radius: 8px; padding: 8px 14px;">
                        <div style="font-size: 0.68rem; color: #00f5a0; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">ENSEMBLE AUC</div>
                        <div style="font-size: 1.15rem; font-weight: 800; color: #00f5a0; font-family: 'Rajdhani', sans-serif;">0.912 ROC-AUC</div>
                    </div>
                    <div style="background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(168, 85, 247, 0.3); border-radius: 8px; padding: 8px 14px;">
                        <div style="font-size: 0.68rem; color: #a855f7; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">DATA QUALITY</div>
                        <div style="font-size: 1.15rem; font-weight: 800; color: #a855f7; font-family: 'Rajdhani', sans-serif;">98.5% VERIFIED</div>
                    </div>
                </div>
            </div>
            
            {img_html}
            
        </div>
    </div>
    """
    st.markdown(banner_html, unsafe_allow_html=True)
