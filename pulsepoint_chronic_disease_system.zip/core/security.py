"""
PulsePoint Cyber-Medical Intelligence System
Authentication, Cryptography & Role-Based Access Control (RBAC)
"""

import os
import hmac
import hashlib
import base64
import json
import time
from typing import Dict, Any, Optional, List
from core.config import SECRET_KEY, ACCESS_TOKEN_EXPIRE_MINUTES

# Role Definitions
ROLE_ADMIN = "Administrator"
ROLE_CLINICIAN = "Authorized Clinician"
ROLE_ANALYST = "Healthcare Analyst"
ROLE_RESEARCHER = "Researcher"
ROLE_VIEWER = "Read-only Viewer"

ALL_ROLES = [ROLE_ADMIN, ROLE_CLINICIAN, ROLE_ANALYST, ROLE_RESEARCHER, ROLE_VIEWER]

# Permissions Mapping
ROLE_PERMISSIONS = {
    ROLE_ADMIN: {
        "view_dashboards": True,
        "view_patient_360": True,
        "export_patient_level": True,
        "export_aggregates": True,
        "manage_alerts": True,
        "train_models": True,
        "view_audit_logs": True,
        "manage_users": True,
    },
    ROLE_CLINICIAN: {
        "view_dashboards": True,
        "view_patient_360": True,
        "export_patient_level": True,
        "export_aggregates": True,
        "manage_alerts": True,
        "train_models": False,
        "view_audit_logs": False,
        "manage_users": False,
    },
    ROLE_ANALYST: {
        "view_dashboards": True,
        "view_patient_360": False,
        "export_patient_level": False,
        "export_aggregates": True,
        "manage_alerts": True,
        "train_models": True,
        "view_audit_logs": False,
        "manage_users": False,
    },
    ROLE_RESEARCHER: {
        "view_dashboards": True,
        "view_patient_360": False,
        "export_patient_level": False,
        "export_aggregates": True,
        "manage_alerts": False,
        "train_models": False,
        "view_audit_logs": False,
        "manage_users": False,
    },
    ROLE_VIEWER: {
        "view_dashboards": True,
        "view_patient_360": False,
        "export_patient_level": False,
        "export_aggregates": False,
        "manage_alerts": False,
        "train_models": False,
        "view_audit_logs": False,
        "manage_users": False,
    }
}


def hash_password(password: str, salt: Optional[str] = None) -> str:
    """
    Hash a password using PBKDF2-HMAC-SHA256 with 100,000 iterations.
    Format: salt$hash
    """
    if salt is None:
        salt = os.urandom(16).hex()
    
    key = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    )
    return f"{salt}${key.hex()}"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain password against the stored salt$hash string."""
    try:
        salt, stored_hash = hashed_password.split('$', 1)
        test_hash = hashlib.pbkdf2_hmac(
            'sha256',
            plain_password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        return hmac.compare_digest(stored_hash, test_hash)
    except Exception:
        return False


def create_access_token(data: Dict[str, Any], expires_delta_minutes: int = ACCESS_TOKEN_EXPIRE_MINUTES) -> str:
    """
    Creates a cryptographically signed compact HMAC-SHA256 token.
    Token structure: base64(header).base64(payload).signature
    """
    header = {"alg": "HS256", "typ": "JWT"}
    payload = data.copy()
    payload["exp"] = int(time.time()) + (expires_delta_minutes * 60)
    payload["iat"] = int(time.time())

    h_b64 = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip("=")
    p_b64 = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
    
    signing_input = f"{h_b64}.{p_b64}".encode()
    signature = hmac.new(SECRET_KEY.encode(), signing_input, hashlib.sha256).hexdigest()
    
    return f"{h_b64}.{p_b64}.{signature}"


def verify_access_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verifies token signature and checks expiration.
    Returns decoded payload if valid, None otherwise.
    """
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        h_b64, p_b64, signature = parts
        
        signing_input = f"{h_b64}.{p_b64}".encode()
        expected_sig = hmac.new(SECRET_KEY.encode(), signing_input, hashlib.sha256).hexdigest()
        
        if not hmac.compare_digest(expected_sig, signature):
            return None
            
        # Add padding back if necessary
        p_padded = p_b64 + "=" * (-len(p_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(p_padded.encode()).decode())
        
        # Check expiration
        if payload.get("exp", 0) < time.time():
            return None
            
        return payload
    except Exception:
        return None


def check_permission(role: str, permission_key: str) -> bool:
    """Checks whether a given role holds a specific permission."""
    perms = ROLE_PERMISSIONS.get(role, {})
    return perms.get(permission_key, False)


# Initial Demo Credentials
DEFAULT_USERS = [
    {
        "username": "admin",
        "full_name": "System Director",
        "email": "admin@pulsepoint.med",
        "role": ROLE_ADMIN,
        "password": hash_password("Admin@2026!")
    },
    {
        "username": "dr_chen",
        "full_name": "Dr. Marcus Chen, MD",
        "email": "mchen@pulsepoint.med",
        "role": ROLE_CLINICIAN,
        "password": hash_password("Clinician@2026!")
    },
    {
        "username": "analyst_sarah",
        "full_name": "Sarah Connor, Lead Data Analyst",
        "email": "sconnor@pulsepoint.med",
        "role": ROLE_ANALYST,
        "password": hash_password("Analyst@2026!")
    },
    {
        "username": "researcher_alex",
        "full_name": "Alex Mercer, Epidemiologist",
        "email": "amercer@pulsepoint.med",
        "role": ROLE_RESEARCHER,
        "password": hash_password("Research@2026!")
    },
    {
        "username": "viewer_guest",
        "full_name": "Guest Auditor",
        "email": "viewer@pulsepoint.med",
        "role": ROLE_VIEWER,
        "password": hash_password("Viewer@2026!")
    }
]
