"""
PulsePoint Cyber-Medical Intelligence System
Database Connection, Schema Initialization & Parameterized Query Interface
"""

import sqlite3
import json
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from core.config import DB_PATH
from core.security import DEFAULT_USERS

def get_connection() -> sqlite3.Connection:
    """Return an open connection to SQLite with row dictionary factory."""
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_database() -> None:
    """Creates all required tables if they do not exist and seeds initial users."""
    conn = get_connection()
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        role TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL,
        last_login TEXT
    );
    """)

    # 2. Patient Records Table (Synthetic Demonstration Data)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS patient_records (
        patient_id TEXT PRIMARY KEY,
        age INTEGER NOT NULL,
        gender TEXT NOT NULL,
        region TEXT NOT NULL,
        bmi REAL NOT NULL,
        bmi_category TEXT NOT NULL,
        systolic_bp INTEGER NOT NULL,
        diastolic_bp INTEGER NOT NULL,
        bp_category TEXT NOT NULL,
        cholesterol_total REAL NOT NULL,
        cholesterol_hdl REAL NOT NULL,
        cholesterol_ldl REAL NOT NULL,
        cholesterol_ratio REAL NOT NULL,
        fasting_glucose REAL NOT NULL,
        glucose_category TEXT NOT NULL,
        hba1c REAL NOT NULL,
        smoking_status TEXT NOT NULL,
        alcohol_consumption TEXT NOT NULL,
        physical_activity_mins INTEGER NOT NULL,
        exercise_level TEXT NOT NULL,
        fatigue_reported INTEGER NOT NULL,
        chest_pain_type TEXT NOT NULL,
        dizziness_reported INTEGER NOT NULL,
        shortness_of_breath INTEGER NOT NULL,
        heart_disease INTEGER NOT NULL,
        diabetes INTEGER NOT NULL,
        stroke INTEGER NOT NULL,
        multimorbidity_count INTEGER NOT NULL,
        data_completeness_pct REAL NOT NULL,
        assessment_date TEXT NOT NULL,
        review_status TEXT NOT NULL,
        is_synthetic INTEGER DEFAULT 1
    );
    """)

    # 3. Data Quality Metrics Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS data_quality_metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        execution_timestamp TEXT NOT NULL,
        total_records INTEGER NOT NULL,
        duplicate_count INTEGER NOT NULL,
        missing_count INTEGER NOT NULL,
        completeness_pct REAL NOT NULL,
        quality_score REAL NOT NULL,
        issues_json TEXT NOT NULL
    );
    """)

    # 4. Model Metadata & Evaluation Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS model_metadata (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        disease_type TEXT NOT NULL,
        model_type TEXT NOT NULL,
        version TEXT NOT NULL,
        train_timestamp TEXT NOT NULL,
        train_samples INTEGER NOT NULL,
        test_samples INTEGER NOT NULL,
        metrics_json TEXT NOT NULL,
        parameters_json TEXT NOT NULL,
        file_path TEXT NOT NULL,
        is_active INTEGER DEFAULT 1
    );
    """)

    # 5. Clinical Alerts Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS clinical_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id TEXT NOT NULL,
        alert_type TEXT NOT NULL,
        severity TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        rule_code TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        created_at TEXT NOT NULL,
        resolved_by TEXT,
        resolution_notes TEXT,
        FOREIGN KEY (patient_id) REFERENCES patient_records (patient_id)
    );
    """)

    # 6. Audit Events Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        username TEXT NOT NULL,
        role TEXT NOT NULL,
        event_type TEXT NOT NULL,
        resource TEXT NOT NULL,
        status TEXT NOT NULL,
        ip_address TEXT,
        details_json TEXT
    );
    """)

    conn.commit()

    # Seed initial users if table is empty
    cursor.execute("SELECT COUNT(*) as count FROM users;")
    row = cursor.fetchone()
    if row and row["count"] == 0:
        now_str = datetime.now(timezone.utc).isoformat()
        for u in DEFAULT_USERS:
            cursor.execute(
                """
                INSERT INTO users (username, full_name, email, role, password_hash, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (u["username"], u["full_name"], u["email"], u["role"], u["password"], now_str)
            )
        conn.commit()

    conn.close()


def query_db(query: str, params: tuple = ()) -> List[Dict[str, Any]]:
    """Safely execute a parameterized SELECT query."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    rows = cursor.fetchall()
    result = [dict(row) for row in rows]
    conn.close()
    return result


def execute_db(query: str, params: tuple = ()) -> int:
    """Safely execute a parameterized INSERT, UPDATE, or DELETE query. Returns lastrowid."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    last_id = cursor.lastrowid
    conn.close()
    return last_id
