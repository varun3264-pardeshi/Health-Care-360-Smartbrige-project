"""
Unit & Integration Tests: Authentication, Cryptography, RBAC, Parameterized Queries & Privacy
"""

import pytest
import time
from core.security import (
    hash_password, verify_password, create_access_token, verify_access_token,
    check_permission, ROLE_ADMIN, ROLE_CLINICIAN, ROLE_ANALYST, ROLE_RESEARCHER, ROLE_VIEWER
)
from core.database import query_db, get_connection
from core.audit import apply_small_cell_suppression, sanitize_audit_details

def test_password_hashing_and_verification():
    """Verify PBKDF2 hashing with random salt and resistance to incorrect passwords."""
    raw_pass = "Clinician@Secure2026!"
    hashed = hash_password(raw_pass)
    
    assert "$" in hashed
    salt, key_hex = hashed.split("$")
    assert len(salt) == 32 # 16 bytes hex
    
    # Correct password succeeds
    assert verify_password(raw_pass, hashed) is True
    # Incorrect password fails
    assert verify_password("WrongPassword!", hashed) is False
    assert verify_password("", hashed) is False


def test_hmac_access_token_and_tampering():
    """Verify cryptographic token generation, expiration, and tampering rejection."""
    payload = {"sub": "dr_chen", "role": ROLE_CLINICIAN}
    token = create_access_token(payload, expires_delta_minutes=60)
    
    # Valid token decodes correctly
    decoded = verify_access_token(token)
    assert decoded is not None
    assert decoded["sub"] == "dr_chen"
    assert decoded["role"] == ROLE_CLINICIAN

    # Tampered signature is rejected
    parts = token.split(".")
    tampered_sig = parts[0] + "." + parts[1] + "." + "0" * len(parts[2])
    assert verify_access_token(tampered_sig) is None

    # Tampered payload is rejected
    tampered_payload = "eyJuYW1lIjoiZXZpbCJ9" + "." + parts[1] + "." + parts[2]
    assert verify_access_token(tampered_payload) is None


def test_role_based_access_control_permissions():
    """Verify least-privilege matrix across all defined enterprise roles."""
    # Administrator has all permissions
    assert check_permission(ROLE_ADMIN, "view_dashboards") is True
    assert check_permission(ROLE_ADMIN, "view_patient_360") is True
    assert check_permission(ROLE_ADMIN, "train_models") is True
    assert check_permission(ROLE_ADMIN, "manage_users") is True

    # Clinician can view Patient 360, but cannot train models or manage users
    assert check_permission(ROLE_CLINICIAN, "view_patient_360") is True
    assert check_permission(ROLE_CLINICIAN, "manage_alerts") is True
    assert check_permission(ROLE_CLINICIAN, "train_models") is False
    assert check_permission(ROLE_CLINICIAN, "manage_users") is False

    # Analyst can train models and export aggregates, but cannot view Patient 360
    assert check_permission(ROLE_ANALYST, "train_models") is True
    assert check_permission(ROLE_ANALYST, "view_patient_360") is False
    assert check_permission(ROLE_ANALYST, "export_patient_level") is False

    # Researcher has aggregate export access only
    assert check_permission(ROLE_RESEARCHER, "export_aggregates") is True
    assert check_permission(ROLE_RESEARCHER, "view_patient_360") is False
    assert check_permission(ROLE_RESEARCHER, "export_patient_level") is False

    # Read-only Viewer cannot export or manage anything
    assert check_permission(ROLE_VIEWER, "view_dashboards") is True
    assert check_permission(ROLE_VIEWER, "export_aggregates") is False
    assert check_permission(ROLE_VIEWER, "manage_alerts") is False


def test_parameterized_query_sql_injection_resistance():
    """Verify parameterized SQL blocks classic injection attacks."""
    # Attempt SQL injection payload
    malicious_input = "' OR '1'='1"
    rows = query_db("SELECT * FROM users WHERE username = ?", (malicious_input,))
    # Parameterization ensures query searches for the literal string, returning 0 rows
    assert len(rows) == 0


def test_small_cell_suppression_hipaa_compliance():
    """Verify small frequency counts (< 5) are suppressed to prevent identity re-identification."""
    assert "<5" in apply_small_cell_suppression(1, threshold=5)
    assert "<5" in apply_small_cell_suppression(4, threshold=5)
    assert apply_small_cell_suppression(5, threshold=5) == "5"
    assert apply_small_cell_suppression(120, threshold=5) == "120"
    assert apply_small_cell_suppression(0, threshold=5) == "0"


def test_audit_sanitization_removes_secrets():
    """Verify audit log sanitizer strips passwords, tokens, and secret keys."""
    raw_details = {
        "user": "test_user",
        "action": "login",
        "password": "SecretPassword123!",
        "auth_token": "bearer-token-12345",
        "api_key": "private-key-value"
    }
    sanitized = sanitize_audit_details(raw_details)
    assert sanitized["user"] == "test_user"
    assert sanitized["action"] == "login"
    assert sanitized["password"] == "[REDACTED]"
    assert sanitized["auth_token"] == "[REDACTED]"
    assert sanitized["api_key"] == "[REDACTED]"
