"""
Cyber-Medical Hero Banner Component
Renders the executive hero card with holographic AI graphics and live cohort telemetry.
"""

import base64
import os
import streamlit as st


@st.cache_data(ttl=3600)
def get_base64_image(image_path: str) -> str:
    """Reads a local image and returns a cached base64 data URI string."""
    if os.path.exists(image_path):
        with open(image_path, "rb") as f:
            data = f.read()
        ext = os.path.splitext(image_path)[1].replace(".", "")
        if ext == "jpg":
            ext = "jpeg"
        return f"data:image/{ext};base64,{base64.b64encode(data).decode('utf-8')}"
    return ""


def render_executive_hero_banner(cohort_count: int, alert_count: int, model_accuracy: str = "94.2%"):
    """
    Renders an ultra-luxurious cyber-medical executive hero card
    with zero leading indentation to prevent Markdown code-block escaping.
    """
    img_path = os.path.join(os.path.dirname(__file__), "..", "assets", "cyber_medical_cardiac_core.jpg")
    img_b64 = get_base64_image(img_path)

    img_html = ""
    if img_b64:
        img_html = (
            f'<div style="flex: 0 0 270px; position: relative; overflow: hidden; border-radius: 12px; '
            f'border: 1px solid rgba(0, 242, 254, 0.45); box-shadow: 0 0 22px rgba(0, 242, 254, 0.25);">'
            f'<img src="{img_b64}" style="width: 100%; height: 175px; object-fit: cover; display: block;" alt="Cyber Cardiac Core"/>'
            f'<div style="position: absolute; bottom: 8px; left: 8px; background: rgba(7, 11, 25, 0.88); '
            f'border: 1px solid #00f2fe; border-radius: 4px; padding: 2px 8px; font-size: 0.68rem; '
            f'font-family: \'Rajdhani\', monospace; color: #00f2fe; letter-spacing: 0.08em;">'
            f'CORE: CARDIAC AI SCANNER</div>'
            f'<div style="position: absolute; top: 8px; right: 8px; width: 8px; height: 8px; '
            f'background: #00f5a0; border-radius: 50%; box-shadow: 0 0 8px #00f5a0;"></div>'
            f'</div>'
        )

    banner_html = (
        f'<div class="cyber-card" style="background: linear-gradient(135deg, rgba(13, 23, 48, 0.94) 0%, rgba(9, 18, 38, 0.96) 100%); '
        f'border: 1px solid rgba(0, 242, 254, 0.38); border-radius: 16px; padding: 1.45rem; margin-bottom: 1.35rem; '
        f'box-shadow: 0 10px 40px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.1); position: relative; overflow: hidden;">'
        f'<div style="position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #00f2fe 0%, #a855f7 50%, #00f5a0 100%);"></div>'
        f'<div style="display: flex; flex-direction: row; gap: 24px; align-items: center; justify-content: space-between; flex-wrap: wrap;">'
        f'<div style="flex: 1 1 440px;">'
        f'<div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(0, 242, 254, 0.12); '
        f'border: 1px solid rgba(0, 242, 254, 0.3); border-radius: 20px; padding: 4px 12px; margin-bottom: 10px;">'
        f'<span style="display: inline-block; width: 6px; height: 6px; background-color: #00f5a0; border-radius: 50%; box-shadow: 0 0 6px #00f5a0;"></span>'
        f'<span style="font-size: 0.72rem; font-family: \'Rajdhani\', sans-serif; font-weight: 700; color: #00f2fe; letter-spacing: 0.1em; text-transform: uppercase;">'
        f'UNIFIED HEALTH INTELLIGENCE NETWORK • CONTROL CENTER v5.0</span></div>'
        f'<h1 style="margin: 0 0 8px 0; font-size: 1.85rem; font-weight: 800; color: #ffffff; letter-spacing: -0.02em; font-family: \'Outfit\', sans-serif;">'
        f'PulsePoint <span style="background: linear-gradient(90deg, #00f2fe, #4facfe); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Cyber-Medical Control Center</span></h1>'
        f'<p style="margin: 0 0 16px 0; color: #94a3b8; font-size: 0.92rem; line-height: 1.5; max-width: 680px;">'
        f'Real-time tri-disease surveillance across <b>Heart Disease</b>, <b>Type 2 Diabetes</b>, and <b>Stroke</b>—empowering '
        f'<b>Dr. Michael Carter</b> (Clinical Risk), <b>Emily Rodriguez</b> (Lifestyle Analytics), and <b>Dr. Priya Nair</b> (Population Health).</p>'
        f'<div style="display: flex; gap: 14px; flex-wrap: wrap;">'
        f'<div style="background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(0, 242, 254, 0.25); border-radius: 8px; padding: 8px 14px;">'
        f'<div style="font-size: 0.68rem; color: #94a3b8; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">ACTIVE COHORT</div>'
        f'<div style="font-size: 1.15rem; font-weight: 800; color: #ffffff; font-family: \'Rajdhani\', sans-serif;">{cohort_count:,} PATIENTS</div></div>'
        f'<div style="background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(255, 51, 102, 0.35); border-radius: 8px; padding: 8px 14px;">'
        f'<div style="font-size: 0.68rem; color: #ff3366; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">ACTIVE ALERTS</div>'
        f'<div style="font-size: 1.15rem; font-weight: 800; color: #ff3366; font-family: \'Rajdhani\', sans-serif;">{alert_count} TRIGGERED</div></div>'
        f'<div style="background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(0, 245, 160, 0.35); border-radius: 8px; padding: 8px 14px;">'
        f'<div style="font-size: 0.68rem; color: #00f5a0; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">ENSEMBLE AUC</div>'
        f'<div style="font-size: 1.15rem; font-weight: 800; color: #00f5a0; font-family: \'Rajdhani\', sans-serif;">0.912 ROC-AUC</div></div>'
        f'<div style="background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(168, 85, 247, 0.35); border-radius: 8px; padding: 8px 14px;">'
        f'<div style="font-size: 0.68rem; color: #a855f7; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">DATA QUALITY</div>'
        f'<div style="font-size: 1.15rem; font-weight: 800; color: #a855f7; font-family: \'Rajdhani\', sans-serif;">98.5% VERIFIED</div></div>'
        f'</div></div>{img_html}</div></div>'
    )
    st.markdown(banner_html, unsafe_allow_html=True)
